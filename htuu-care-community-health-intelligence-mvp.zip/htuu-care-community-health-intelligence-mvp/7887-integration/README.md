# 7887 Integration

The 7887 integration should provide only approved, aggregated information-demand indicators.

Example:
- date bucket
- health topic
- count
- approved geographic aggregation

Never send raw call recordings, phone numbers, names, or identifiable clinical information to the public intelligence API.
