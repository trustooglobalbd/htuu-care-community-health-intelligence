# Htuu Care – Community Health Intelligence MVP

This package is the first working MVP layer for the Htuu Care + 7887 Community Health Intelligence concept.

## Run locally

Requirements:
- Node.js 20+

Commands:

```bash
npm run classify -- "people asking about heat stress"
npm run analyze
npm test
```

## Cloudflare Worker

The Worker is in `cloudflare/worker.js`.

With Wrangler installed:

```bash
cd cloudflare
npx wrangler dev
```

Deploy only after reviewing account configuration, access controls, data governance, and secrets.

## Architecture

Htuu Care + 7887
→ approved aggregated signals
→ topic classification
→ trend analysis
→ Cloudflare API
→ dashboard
→ human/public-health review

## Safety

This MVP is non-diagnostic.

It must not:
- diagnose individuals;
- prescribe treatment;
- identify individuals;
- expose private conversations;
- make autonomous public-health decisions.

Use aggregated and non-identifying data for community intelligence.
