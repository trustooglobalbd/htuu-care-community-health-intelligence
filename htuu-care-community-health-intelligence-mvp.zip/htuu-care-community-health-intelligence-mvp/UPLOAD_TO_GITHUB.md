# Upload to GitHub

1. Extract this ZIP.
2. Open the repository:
   `trustooglobalbd/htuu-care-community-health-intelligence`
3. Upload the extracted files/folders.
4. Commit to the main branch.
5. Run the Node.js tests locally before deployment.
6. Do not upload `.env`, API keys, Telegram tokens, or personal health data.

If the repository already contains the documentation-only version, replace/add the files from this MVP package carefully rather than deleting working Htuu Care code.
