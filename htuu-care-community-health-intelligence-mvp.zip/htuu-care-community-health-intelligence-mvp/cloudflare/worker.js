const ALLOWED_ORIGIN = "*";

const json = (data, status = 200) =>
  new Response(JSON.stringify(data, null, 2), {
    status,
    headers: {
      "content-type": "application/json",
      "access-control-allow-origin": ALLOWED_ORIGIN,
      "access-control-allow-methods": "GET,POST,OPTIONS",
      "access-control-allow-headers": "content-type,authorization"
    }
  });

export default {
  async fetch(request, env) {
    if (request.method === "OPTIONS") return json({ ok: true });

    const url = new URL(request.url);

    if (url.pathname === "/health") {
      return json({
        status: "ok",
        service: "Htuu Care Community Health Intelligence API",
        safety: "non-diagnostic"
      });
    }

    if (url.pathname === "/api/v1/signal" && request.method === "POST") {
      const body = await request.json().catch(() => null);

      if (!body || !body.topic || typeof body.count !== "number") {
        return json({
          error: "topic and numeric count are required"
        }, 400);
      }

      return json({
        accepted: true,
        topic: body.topic,
        count: body.count,
        interpretation: "Aggregated information-demand signal. Human review required."
      }, 202);
    }

    return json({
      service: "Htuu Care Community Health Intelligence API",
      endpoints: ["/health", "/api/v1/signal"]
    });
  }
};
