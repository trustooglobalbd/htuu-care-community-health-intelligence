const fs = require("fs");
const path = require("path");

const taxonomy = JSON.parse(
  fs.readFileSync(path.join(__dirname, "topics.json"), "utf8")
);

function classify(text) {
  const input = String(text || "").toLowerCase();
  let best = { topic: "other", score: 0 };

  for (const [topic, keywords] of Object.entries(taxonomy)) {
    let score = 0;
    for (const keyword of keywords) {
      if (input.includes(keyword.toLowerCase())) score++;
    }
    if (score > best.score) best = { topic, score };
  }

  return best.topic;
}

if (require.main === module) {
  const text = process.argv.slice(2).join(" ");
  console.log(JSON.stringify({ topic: classify(text) }, null, 2));
}

module.exports = { classify };
