# Trend Analysis

The MVP compares the latest available aggregated count with the previous period.

A review signal is generated when demand increases by 50% or more.

This is an information-demand signal only. It is not an outbreak detector and must not be interpreted as a diagnosis.
