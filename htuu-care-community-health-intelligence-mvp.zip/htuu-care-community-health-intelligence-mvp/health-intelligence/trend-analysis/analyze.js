const fs = require("fs");
const path = require("path");

const csvPath = path.join(__dirname, "../sample-data/sample_health_demand.csv");
const csv = fs.readFileSync(csvPath, "utf8").trim().split(/\r?\n/);
const rows = csv.slice(1).map(line => {
  const [date, topic, count] = line.split(",");
  return { date, topic, count: Number(count) };
});

const grouped = {};
for (const row of rows) {
  grouped[row.topic] ??= [];
  grouped[row.topic].push(row);
}

const signals = Object.entries(grouped).map(([topic, values]) => {
  values.sort((a, b) => a.date.localeCompare(b.date));
  const previous = values.at(-2)?.count ?? 0;
  const latest = values.at(-1)?.count ?? 0;
  const changePct = previous === 0 ? null : ((latest - previous) / previous) * 100;

  return {
    topic,
    previous_count: previous,
    latest_count: latest,
    change_percent: changePct === null ? null : Number(changePct.toFixed(1)),
    review_recommended: changePct !== null && changePct >= 50
  };
});

console.log(JSON.stringify({
  generated_at: new Date().toISOString(),
  interpretation: "Aggregated health-information demand only; not a disease or outbreak diagnosis.",
  signals
}, null, 2));
