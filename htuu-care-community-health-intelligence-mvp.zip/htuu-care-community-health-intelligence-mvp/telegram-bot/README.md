# Htuu Care Integration

Connect the existing Htuu Care Telegram Bot to the intelligence API only after an approved data-governance review.

Recommended payload:
{
  "topic": "heat_environmental_health",
  "count": 1,
  "period": "daily"
}

Do not send usernames, phone numbers, chat IDs, message text, medical records, or raw conversations to the public intelligence endpoint.
