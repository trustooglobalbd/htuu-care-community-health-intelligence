const test = require("node:test");
const assert = require("node:assert/strict");
const { classify } = require("../health-intelligence/topic-classification/classify");

test("classifies heat-related information", () => {
  assert.equal(classify("What should I know about heat stress?"), "heat_environmental_health");
});

test("classifies maternal health information", () => {
  assert.equal(classify("Pregnancy and breastfeeding information"), "maternal_child_health");
});

test("returns other when no topic matches", () => {
  assert.equal(classify("Hello there"), "other");
});
